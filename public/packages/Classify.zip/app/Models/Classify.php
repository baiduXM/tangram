<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;


/**
 * 栏目数据模型
 *
 * @author 12t
 */
class Classify extends Model{
    protected $table="classify";
}
