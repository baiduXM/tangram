<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;


/**
 * 文章数据模型
 *
 * @author 12t
 */
class Articles extends Model{
    protected $table="article";
}
